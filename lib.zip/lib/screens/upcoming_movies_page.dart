import 'package:flutter/material.dart';
import '../services/movie_service.dart';
import '../utils/paginated_list.dart';
import '../utils/data_adapter.dart';
import '../widgets/movie_list_tile.dart';
import 'common_detail_screen.dart';
import '../utils/home_cache.dart';

class UpcomingMoviesPage extends StatefulWidget {
  const UpcomingMoviesPage({super.key});

  @override
  State<UpcomingMoviesPage> createState() => _UpcomingMoviesPageState();
}

class _UpcomingMoviesPageState extends State<UpcomingMoviesPage> {
  Future<List> fetch() => MovieService.fetchUpcoming();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0F0F0F),
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text("Upcoming Movies"),
      ),
      body: PaginatedList(
        pageSize: 15,
        fetch: fetch,
        builder: (m) {
          return MovieListTile(
            id: m["unique_id"]?.toString() ?? "",
            title: DataAdapter.extractTitle(m),
            language: DataAdapter.extractLanguage(m),
            posterOverride: DataAdapter.extractPoster(m),
            onTap: () async {
              final uniqueId = m["unique_id"]?.toString() ?? "";
              print("🟢 [UPCOMING TAP] unique_id=$uniqueId");
              if (uniqueId.isEmpty) return;

              final movie = await MovieService.fetchUpcomingByUniqueId(uniqueId);
              if (!context.mounted || movie == null) return;

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CommonDetailScreen(
                    data: movie,
                    exploreList: HomeCache.upcoming,
                    isUpcoming: true,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}