import '../services/movie_service.dart';
import 'package:flutter/material.dart';
import '../utils/paginated_list.dart';
import '../utils/data_adapter.dart';
import '../utils/home_cache.dart';
import '../widgets/movie_list_tile.dart';
import 'common_detail_screen.dart';

class AllMoviesPage extends StatefulWidget {
  const AllMoviesPage({super.key});

  @override
  State<AllMoviesPage> createState() => _AllMoviesPageState();
}

class _AllMoviesPageState extends State<AllMoviesPage> {
  Future<List> fetch() => MovieService.fetchLatest();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0F0F0F),
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text("Latest Movies"),
      ),
      body: PaginatedList(
        pageSize: 15,
        fetch: fetch,
        builder: (m) {
          return MovieListTile(
            id: m["unique_id"]?.toString() ?? "",
            title: DataAdapter.extractTitle(m),
            language: DataAdapter.extractLanguage(m),
            posterOverride: DataAdapter.extractPoster(m),
            onTap: () async {
              final uniqueId = m["unique_id"]?.toString() ?? "";
              print("🟢 [ALL MOVIES TAP] unique_id=$uniqueId");
              if (uniqueId.isEmpty) return;

              final movie = await MovieService.fetchLatestByUniqueId(uniqueId);
              if (!context.mounted || movie == null) return;

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CommonDetailScreen(
                    data: movie,
                    exploreList: HomeCache.latest,
                    isLatest: true,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}