import 'package:flutter/material.dart';
import '../services/movie_service.dart';
import '../utils/paginated_list.dart';
import '../utils/data_adapter.dart';
import '../utils/home_cache.dart';
import '../widgets/movie_list_tile.dart';
import 'common_detail_screen.dart';

class FullMoviesPage extends StatefulWidget {
  const FullMoviesPage({super.key});

  @override
  State<FullMoviesPage> createState() => _FullMoviesPageState();
}

class _FullMoviesPageState extends State<FullMoviesPage> {
  Future<List> fetch() async {
    final data = await MovieService.fetchFull();
    print("=== [FULL MOVIES] Fetched: ${data.length} items");
    return data;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0F0F0F),
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text("Latest Full Movies"),
      ),
      body: PaginatedList(
        pageSize: 15,
        fetch: fetch,
        builder: (m) {
          final uniqueId = DataAdapter.extractUniqueIdFromWatchUrl(m) ?? "";

          return MovieListTile(
            id: m["film_id"]?.toString() ?? uniqueId,
            title: DataAdapter.extractTitle(m),
            language: DataAdapter.extractLanguage(m),
            categorySlug: DataAdapter.extractCategorySlug(m),
            posterOverride: DataAdapter.extractPoster(m),
            onTap: () async {
              print("=== [FULL MOVIE TAP] unique_id=$uniqueId");
              if (uniqueId.isEmpty) return;

              final movie = await MovieService.fetchFullMovieByUniqueId(uniqueId);
              if (!context.mounted) return;
              if (movie == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Movie not found")),
                );
                return;
              }

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CommonDetailScreen(
                    data: movie,
                    exploreList: HomeCache.full,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}